select count(*) as count from clients where client_login_name like :pattern:;
